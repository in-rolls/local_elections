
**********************************************************************************************************************
* This do-file provides codes used for the household level anaylsis in the paper "How Do Voters Respond to Welfare vis-à-vis Public Good Programs? Theory and Evidence of Political Clientelism" by Pranab Bardhan, Sandip Mitra, Dilip Mookherjee, and Anusha Nath 

* List of tables and figures that can be replicated using this do-file:
*
* 		Table/Figure			  Line of code 
*	   ~~~~~~~~~~~~~~~~			~~~~~~~~~~~~~~~~
* 		Table 1:					 56 
* 		Table 3:					 107 
* 		Table 8:					 196 
* 		Table 9:				     256 
* 		Table A1:					 337 
* 		Table A12:					 431 
* 		Table A13:					 492 
* 		Figure 3: 					 553 

* Stata version: 					 Stata/MP 14.0 for Mac (64-bit Intel)
* Time to run this code: 			 4.635 seconds
* Output produced from this file is stored in the empty sub-folder called "replication_output"

*~~~~~~~~~~~~~~~~~
* INSTRUCTIONS: 
*~~~~~~~~~~~~~~~~~
* Change the directory path on line 48 to where the replication folder is saved.

*******************************************************************************************
*******************************************************************************************

set more off

* Installing required packages
    local ssc_packages "estout" "esttab" "ivreg2" "weakiv" "avar"
    if !missing("`ssc_packages'") {
        foreach pkg in "`ssc_packages'" {
        * install using ssc, but avoid re-installing if already present
            capture which `pkg'
            if _rc == 111 {                 
               dis "Installing `pkg'"
               quietly ssc install `pkg', replace
               }
        }
    }

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

* Change directory to where the folder is saved
*cd XXX

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table 1
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

*** Official data (columns 1 and 2)

clear
use Household_Data.dta

keep village old_ac new_ac share_aitc2006 share_inc2006 share_left2006 share_others2006 turnout_2006 share_aitc2011 share_inc2011 share_left2011 share_others2011 turnout_2011
duplicates drop 

foreach i of newlist aitc inc left others {
qui sum share_`i'2006
mat define a_`i'06=r(mean)
qui sum share_`i'2011
mat define a_`i'11=r(mean)
}

qui sum turnout_2006 
mat define a_turnout06=r(mean)
qui sum turnout_2011 
mat define a_turnout11=r(mean)

mat define A=a_aitc06\a_left06\a_inc06\a_others06\a_turnout06
mat define B=a_aitc11\a_left11\a_inc11\a_others11\a_turnout11

mat define C=A, B

mat colnames C=2006 2011
mat rownames C=TMC Left_Front INC Others Voter_Turnout

log using "replication_output/Table1a_output", replace
mat list C
log close

*** Poll data (columns 3 and 4)
clear
use Household_Data.dta

keep hhid votefor2004 votefor2011
duplicates drop 

foreach i of numlist 2004 2011 {
	replace votefor`i'="TMC" if votefor`i'=="AITC"
	replace votefor`i'="Didn't Respond" if votefor`i'=="Didn't Vote"
}

log using "replication_output/Table1b_output", replace
tab votefor2004 
tab votefor2011
log close

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table 3
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear
use Household_Data.dta

foreach i of varlist  hhben_anybenadj_0406 hhben_anybenadj_0708 hhben_anybenadj_0911  	hhben_anybenadj_0411 ///
	hhben_private_0406		hhben_private_0708 		hhben_private_0911  		hhben_private_0411 ///
	hhben_publicadj_0406	hhben_publicadj_0708	hhben_publicadj_0911   		hhben_publicadj_0411 ///
	hhben_employment_0406  	hhben_employment_0708   hhben_employment_0911		hhben_employment_0411  ///
	hhben_irdp_0406 		hhben_irdp_0708			hhben_irdp_0911    			hhben_irdp_0411    ///
	hhben_minikit_0406 		hhben_minikit_0708	  	hhben_minikit_0911	 		hhben_minikit_0411   ///
	hhben_ration_0406 	 	hhben_ration_0708	    hhben_ration_0911 			hhben_ration_0411      ///
	hhben_housetoilet_0406	hhben_housetoilet_0708  hhben_housetoilet_0911	 	hhben_housetoilet_0411   ///
	hhben_drinkingwater_0406	hhben_drinkingwater_0708 hhben_drinkingwater_0911 	hhben_drinkingwater_0411    ///
 	hhben_irrigationadj_0406	hhben_irrigationadj_0708 hhben_irrigationadj_0911 	hhben_irrigationadj_0411   ///	
	hhben_roadadj_0406	 	hhben_roadadj_0708		hhben_roadadj_0911			hhben_roadadj_0411 	///
	hhben_other_0406 		hhben_other_0708		hhben_other_0911 			hhben_other_0411           {
sum `i'
gen r`i'=r(mean)
}

foreach i in rhhben_anybenadj_0406  rhhben_private_0406  rhhben_publicadj_0406  rhhben_ration_0406  /// 
			rhhben_irdp_0406  rhhben_drinkingwater_0406  rhhben_employment_0406  rhhben_housetoilet_0406  ///
			rhhben_irrigationadj_0406 rhhben_minikit_0406  rhhben_roadadj_0406  ///
			rhhben_other_0406 {
sum `i'
mat define a_`i'=r(mean)
}

foreach i in rhhben_anybenadj_0708 rhhben_private_0708 rhhben_publicadj_0708  rhhben_ration_0708    ///
			rhhben_irdp_0708 rhhben_drinkingwater_0708  rhhben_employment_0708  rhhben_housetoilet_0708  ///
			rhhben_irrigationadj_0708 rhhben_minikit_0708  rhhben_roadadj_0708  ///
			rhhben_other_0708 {
sum `i'
mat define b_`i'=r(mean)
}

foreach i in rhhben_anybenadj_0911 rhhben_private_0911 rhhben_publicadj_0911  rhhben_ration_0911   ///
			rhhben_irdp_0911  rhhben_drinkingwater_0911  rhhben_employment_0911  rhhben_housetoilet_0911  /// 
			 rhhben_irrigationadj_0911 rhhben_minikit_0911  rhhben_roadadj_0911  ///
			 rhhben_other_0911 {
sum `i'
mat define c_`i'=r(mean)
}

foreach i in rhhben_anybenadj_0411 rhhben_private_0411 rhhben_publicadj_0411  rhhben_ration_0411   ///
			rhhben_irdp_0411  rhhben_drinkingwater_0411  rhhben_employment_0411  rhhben_housetoilet_0411  /// 
			 rhhben_irrigationadj_0411 rhhben_minikit_0411  rhhben_roadadj_0411  ///
			 rhhben_other_0411 {
sum `i'
mat define d_`i'=r(mean)
}


mat define A= a_rhhben_anybenadj_0406 \ a_rhhben_private_0406  \ a_rhhben_ration_0406 \ a_rhhben_irdp_0406  ///
				\ a_rhhben_drinkingwater_0406 \ a_rhhben_employment_0406 \ a_rhhben_housetoilet_0406 ///
				\ a_rhhben_minikit_0406 \ a_rhhben_publicadj_0406  \ a_rhhben_roadadj_0406 \ a_rhhben_irrigationadj_0406 ///
				\ a_rhhben_other_0406
mat define B=b_rhhben_anybenadj_0708 \ b_rhhben_private_0708  \ b_rhhben_ration_0708 \ b_rhhben_irdp_0708  ///
				\ b_rhhben_drinkingwater_0708 \ b_rhhben_employment_0708 \ b_rhhben_housetoilet_0708 ///
				\ b_rhhben_minikit_0708 \ b_rhhben_publicadj_0708 \ b_rhhben_roadadj_0708 \ b_rhhben_irrigationadj_0708 ///
				\ b_rhhben_other_0708
mat define C=c_rhhben_anybenadj_0911 \ c_rhhben_private_0911  \ c_rhhben_ration_0911 \  c_rhhben_irdp_0911 ///
				\ c_rhhben_drinkingwater_0911 \ c_rhhben_employment_0911 \ c_rhhben_housetoilet_0911 ///
				\ c_rhhben_minikit_0911 \ c_rhhben_publicadj_0911  \ c_rhhben_roadadj_0911 \  c_rhhben_irrigationadj_0911  ///
				\ c_rhhben_other_0911
mat define D=d_rhhben_anybenadj_0411 \ d_rhhben_private_0411  \ d_rhhben_ration_0411 \  d_rhhben_irdp_0411 ///
				\ d_rhhben_drinkingwater_0411 \ d_rhhben_employment_0411 \ d_rhhben_housetoilet_0411 ///
				\ d_rhhben_minikit_0411 \ d_rhhben_publicadj_0411  \ d_rhhben_roadadj_0411 \  d_rhhben_irrigationadj_0411  ///
				\ d_rhhben_other_0411				
				
				
				
mat colnames A=2004-06
mat colnames B=2007-08
mat colnames C=2009-11
mat colnames D=2004-11

mat define E=D, A, B, C 
mat rownames E= AnyBenefits PrivateBenefits  BPLCards Credit DrinkingWater Employment Housing Minikits ///
				PublicBenefits RoadBenefits Irrigation OtherBenefits

log using "replication_output/Table3_output", replace  
mat list E, format(%12.2f)
log close


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table 8
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear
use Household_Data.dta
		
label variable stdzd_pvtnumben_0911 				"Private Benefits"
label variable stdzd_pubnumben_0911					"Public Benefits"
label variable stdzd_pcdistallben_0911 				"Sd(v)"		
label variable stdzd_pcdistallben_0911_scst 		"Sd(v) x SC/ST"
label variable stdzd_pcdistallben_0911_landless		"Sd(v) x Landless"
label variable stdzd_pcdistallben_0911_noeduc 		"Sd(v) x No Education"
label variable stdzd_pcdistallben_0911_hindu		"Sd(v) x Hindu"

set more off		
eststo clear		
eststo: reg voted_incumbent2011  ///
        stdzd_pvtnumben_0911 stdzd_pubnumben_0911 ///
		 scst_hoh landless noeduc hindu pr_occhoh_cult ///
		districtdum*  leftgp08 leftpanchsam08 aligned_gpps, cluster(village)	
estadd ysumm		
* First Stage - Pvt
eststo: reg stdzd_pvtnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum*  leftgp08 leftpanchsam08 aligned_gpps if voted_incumbent2011!=., cluster(village)			
estadd ysumm	
* First Stage - Pub
eststo: reg stdzd_pubnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum*  leftgp08 leftpanchsam08 aligned_gpps if voted_incumbent2011!=., cluster(village)				
estadd ysumm	
* Second Stage		
eststo: ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum* leftgp08 leftpanchsam08 aligned_gpps, cluster(village)	 first
estadd ysumm	
esttab using "replication_output/Table8_output.tex", nocon ar2 label replace nogaps compress alignment(p{2.25cm}<{\centering}  ///
  		p{2.25cm}<{\centering} p{2.25cm}<{\centering} p{2.25cm}<{\centering}) b(2) se(2) nonotes ///
		title(2011, cluster village, district FE)  ///
		nomtitle     nostar ///
		keep(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 ///			
		order(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 
encode village, gen(village_num)			
weakiv ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum*  leftgp08 leftpanchsam08 aligned_gpps, cluster(village_num)
	
	
	
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table 9
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear
use Household_Data.dta
	
keep	voted_incumbent2004 voted_incumbent2011 ///
	stdzd_pvtnumben_0103 stdzd_pubnumben_0103 stdzd_pvtnumben_0911 stdzd_pubnumben_0911 ///		
	stdzd_pcdistallben_0103 stdzd_pcdistallben_0103_scst stdzd_pcdistallben_0103_landless stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0103_noeduc stdzd_pcdistallben_0103_hindu stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	leftgp03 leftpanchsam03 leftgp08 leftpanchsam08 ///
	hhid district village grampanchayat 
duplicates drop 	
	
rename stdzd_pvtnumben_0103 				stdzd_pvtnumben2004
rename stdzd_pubnumben_0103					stdzd_pubnumben2004
rename stdzd_pcdistallben_0103 				stdzd_pcdistallben2004 
rename stdzd_pcdistallben_0103_scst 		stdzd_pcdistallben_scst2004 
rename stdzd_pcdistallben_0103_landless 	stdzd_pcdistallben_landless2004
rename stdzd_pcdistallben_0103_noeduc 		stdzd_pcdistallben_noeduc2004 
rename stdzd_pcdistallben_0103_hindu 		stdzd_pcdistallben_hindu2004
rename leftgp03 							leftgp2004 
rename leftpanchsam03 						leftpanchsam2004

rename stdzd_pvtnumben_0911 				stdzd_pvtnumben2011 
rename stdzd_pubnumben_0911 				stdzd_pubnumben2011
rename stdzd_pcdistallben_0911 				stdzd_pcdistallben2011 
rename stdzd_pcdistallben_0911_scst 		stdzd_pcdistallben_scst2011 
rename stdzd_pcdistallben_0911_landless  	stdzd_pcdistallben_landless2011
rename stdzd_pcdistallben_0911_noeduc    	stdzd_pcdistallben_noeduc2011
rename stdzd_pcdistallben_0911_hindu     	stdzd_pcdistallben_hindu2011
rename leftgp08								leftgp2011
rename leftpanchsam08 						leftpanchsam2011

drop if hhid==.

reshape long voted_incumbent stdzd_pcdistallben stdzd_pvtnumben stdzd_pubnumben stdzd_pcdistallben_scst stdzd_pcdistallben_noeduc stdzd_pcdistallben_landless stdzd_pcdistallben_hindu leftpanchsam leftgp, i(hhid) j(year)


gen aligned_gpps=.
replace aligned_gpps=1 if leftgp==1 & leftpanchsam==1 
replace aligned_gpps=1 if leftgp==0 & leftpanchsam==0 
mvencode aligned_gpps, mv(0)

tab district, gen(districtdum)
rename districtdum1 basedistrictdum

xtset hhid year

gen surveyround2011_dum=1 if year==2011
mvencode surveyround2011_dum, mv(0)

label variable stdzd_pvtnumben  "Private Benefits"
label variable stdzd_pubnumben 	"Public Benefits"

label variable leftgp  			"Left GP"
label variable leftpanchsam 	"Left PS"
label variable aligned_gpps		"Aligned GP and PS"

set more off		
eststo clear		
eststo: xtreg voted_incumbent  ///
        stdzd_pvtnumben stdzd_pubnumben, cluster(village) fe
eststo: xtreg voted_incumbent  ///
        stdzd_pvtnumben stdzd_pubnumben leftgp leftpanchsam aligned_gpps, cluster(village) fe	
eststo: xtreg voted_incumbent  ///
        surveyround2011_dum stdzd_pvtnumben stdzd_pubnumben, cluster(village) fe
eststo: xtreg voted_incumbent  ///
		surveyround2011_dum stdzd_pvtnumben stdzd_pubnumben leftgp leftpanchsam aligned_gpps, cluster(village) fe				
esttab using "replication_output/Table9_output.tex", nocon ar2 label replace nogaps compress alignment(p{2.25cm}<{\centering}  ///
  		p{2.25cm}<{\centering} p{2.25cm}<{\centering} p{2.25cm}<{\centering}) b(2) se(2) nonotes ///
		title(Pooled Regression, Household FE)  ///
		nomtitle    nostar ///
		keep(stdzd_pvtnumben stdzd_pubnumben leftgp leftpanchsam aligned_gpps)	 ///			
		order(stdzd_pvtnumben stdzd_pubnumben leftgp leftpanchsam aligned_gpps)	 
		
		
	
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A1
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

* Public goods	
clear 
use "Household_Data.dta"
keep proportion_pairs_same_pub* village 
duplicates drop

reshape long proportion_pairs_same_pub, i(village) j(year)

qui count 
	qui gen n_total=r(N)
qui count if proportion_pairs_same_pub>=0.95
	qui gen n_95higher=r(N)
qui count if proportion_pairs_same_pub>=0.90
	qui gen n_90higher=r(N)	
qui count if proportion_pairs_same_pub>=0.85
	qui gen n_85higher=r(N)
qui count if proportion_pairs_same_pub>=0.80
	qui gen n_80higher=r(N)
qui count if proportion_pairs_same_pub>=0.75
	qui gen n_75higher=r(N)
qui count if proportion_pairs_same_pub>=0.70
	qui gen n_70higher=r(N)
qui count if proportion_pairs_same_pub>=0.65
	qui gen n_65higher=r(N)
qui count if proportion_pairs_same_pub>=0.60
	qui gen n_60higher=r(N)
qui count if proportion_pairs_same_pub>=0.55
	qui gen n_55higher=r(N)
qui count if proportion_pairs_same_pub>=0.50	
	qui gen n_50higher=r(N)

log using "replication_output/TableA1a_output.smcl", replace	
*** PUBLIC GOODS
di n_95higher/n_total
di n_90higher/n_total
di n_85higher/n_total
di n_80higher/n_total	
di n_75higher/n_total
di n_70higher/n_total
di n_65higher/n_total
di n_60higher/n_total
di n_55higher/n_total
di n_50higher/n_total
log close
			 
* Private goods	
clear 
use "Household_Data.dta"
keep proportion_pairs_same_pvt* village 
duplicates drop

reshape long proportion_pairs_same_pvt, i(village) j(year)


qui count 	
	qui gen n_total=r(N)		 
qui count if proportion_pairs_same_pvt>=0.95
	qui gen n_95higher=r(N)
qui count if proportion_pairs_same_pvt>=0.90
	qui gen n_90higher=r(N)	
qui count if proportion_pairs_same_pvt>=0.85
	qui gen n_85higher=r(N)
qui count if proportion_pairs_same_pvt>=0.80
	qui gen n_80higher=r(N)
qui count if proportion_pairs_same_pvt>=0.75
	qui gen n_75higher=r(N)
qui count if proportion_pairs_same_pvt>=0.70
	qui gen n_70higher=r(N)
qui count if proportion_pairs_same_pvt>=0.65
	qui gen n_65higher=r(N)
qui count if proportion_pairs_same_pvt>=0.60
	qui gen n_60higher=r(N)
qui count if proportion_pairs_same_pvt>=0.55
	qui gen n_55higher=r(N)
qui count if proportion_pairs_same_pvt>=0.50
	qui gen n_50higher=r(N)

log using "replication_output/TableA1b_output.smcl"	, replace	
*** PRIVATE GOODS
di n_95higher/n_total
di n_90higher/n_total
di n_85higher/n_total
di n_80higher/n_total	
di n_75higher/n_total
di n_70higher/n_total
di n_65higher/n_total
di n_60higher/n_total
di n_55higher/n_total
di n_50higher/n_total	
log close	
	
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table A12 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
	
clear
use Household_Data.dta
	
encode village, gen(village_num)
	
label variable stdzd_pvtnumben_0911 				"Private Benefits"
label variable stdzd_pubnumben_0911					"Public Benefits"
label variable stdzd_pcdistallben_0911 				"Sd(v)"		
label variable stdzd_pcdistallben_0911_scst 		"Sd(v) x SC/ST"
label variable stdzd_pcdistallben_0911_landless		"Sd(v) x Landless"
label variable stdzd_pcdistallben_0911_noeduc 		"Sd(v) x No Education"
label variable stdzd_pcdistallben_0911_hindu		"Sd(v) x Hindu"
	
set more off		
eststo clear		
eststo: reg voted_incumbent2011  ///
        stdzd_pvtnumben_0911 stdzd_pubnumben_0911 ///
		 scst_hoh landless noeduc hindu pr_occhoh_cult ///
		leftgp08 leftpanchsam08 aligned_gpps, cluster(village)	
estadd ysumm		
* First Stage - Pvt
eststo: reg stdzd_pvtnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	leftgp08 leftpanchsam08 aligned_gpps  if voted_incumbent2011!=., cluster(village)			
estadd ysumm	
* First Stage - Pub
eststo: reg stdzd_pubnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	leftgp08 leftpanchsam08 aligned_gpps  if voted_incumbent2011!=., cluster(village)				
estadd ysumm	
* Second Stage		
eststo: ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	leftgp08 leftpanchsam08 aligned_gpps, cluster(village)	 first
estadd ysumm	
esttab using "replication_output/TableA12_output.tex", nocon ar2 label replace nogaps compress alignment(p{2.25cm}<{\centering}  ///
  		p{2.25cm}<{\centering} p{2.25cm}<{\centering} p{2.25cm}<{\centering}) b(2) se(2) nonotes ///
		title(2011, cluster village, district FE)  ///
		nomtitle    nostar ///
		keep(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 ///			
		order(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 		

weakiv ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	leftgp08 leftpanchsam08 aligned_gpps, cluster(village_num)

	
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.	
* Table A13 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear
use Household_Data.dta	

encode district, gen(district_num)

label variable stdzd_pvtnumben_0911 				"Private Benefits"
label variable stdzd_pubnumben_0911					"Public Benefits"
label variable stdzd_pcdistallben_0911 				"Sd(v)"		
label variable stdzd_pcdistallben_0911_scst 		"Sd(v) x SC/ST"
label variable stdzd_pcdistallben_0911_landless		"Sd(v) x Landless"
label variable stdzd_pcdistallben_0911_noeduc 		"Sd(v) x No Education"
label variable stdzd_pcdistallben_0911_hindu		"Sd(v) x Hindu"		
	
set more off		
eststo clear	
eststo: reg voted_incumbent2011  ///
        stdzd_pvtnumben_0911 stdzd_pubnumben_0911 ///
		scst_hoh landless noeduc hindu pr_occhoh_cult ///
		districtdum*  leftgp08 leftpanchsam08 aligned_gpps , cluster(district)	
*estadd ysumm			
* First Stage - Pvt
eststo: reg stdzd_pvtnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum* leftgp08 leftpanchsam08 aligned_gpps  if voted_incumbent2011!=., cluster(district)			
*estadd ysumm	
* First Stage - Pub
eststo: reg stdzd_pubnumben_0911 ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum* leftgp08 leftpanchsam08 aligned_gpps  if voted_incumbent2011!=., cluster(district)				
*estadd ysumm	
* Second Stage				
eststo: ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum*  leftgp08 leftpanchsam08 aligned_gpps, cluster(district)	 first 
*estadd ysumm	
esttab using "replication_output/TableA13_output.tex", nocon ar2 label replace nogaps compress alignment(p{2.25cm}<{\centering}  ///
  		p{2.25cm}<{\centering} p{2.25cm}<{\centering} p{2.25cm}<{\centering}) b(2) se(2) nonotes ///
		title(2011, cluster district, district FE)  ///
		nomtitle    nostar ///
		keep(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 ///			
		order(stdzd_pvtnumben_0911 stdzd_pubnumben_0911 stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
			stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu)	 
			
weakiv ivreg2 voted_incumbent2011 (stdzd_pvtnumben_0911 stdzd_pubnumben_0911 = ///		
	stdzd_pcdistallben_0911 stdzd_pcdistallben_0911_scst stdzd_pcdistallben_0911_landless ///
	stdzd_pcdistallben_0911_noeduc stdzd_pcdistallben_0911_hindu) ///
	scst_hoh landless noeduc hindu pr_occhoh_cult 	 ///	
	districtdum* leftgp08 leftpanchsam08 aligned_gpps, cluster(district_num)	
	

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Figure 3 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
	
clear
use Household_Data.dta	


keep village propadmin_left2011 propstraw_left2011 propadmin_left2006 propstraw_left2006 
duplicates drop

gen case_id = _n
reshape long propadmin_left propstraw_left, i(case_id) j(year)
replace propadmin_left= propadmin_left*100
replace propstraw_left= propstraw_left*100

pwcorr propadmin_left propstraw_left, sig 
graph twoway (scatter propadmin_left propstraw_left, ///
		ytitle("% Votes for Left Front in Assembly Elections", height(7)) ///
		xtitle("% Votes for Left Front in Post-Election Polls", height(7)) ///
		graphregion(color(white)) bgcolor(white) legend(off)) ///
			(line propstraw_left propstraw_left) ///		
			(lfit propadmin_left propstraw_left)
graph export "replication_output/Figure3_output.pdf", as(pdf) name("Graph")	replace		



