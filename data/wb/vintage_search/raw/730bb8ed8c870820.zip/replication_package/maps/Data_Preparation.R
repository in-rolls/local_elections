#############################################################
#############################################################
#install required packages 
packages = c("ggplot2", 
             "data.table", 
             "foreign",
             "readstata13", 
             "tidyverse",
             "geosphere",
             "dplyr",
             "stringr",
             "sf"
)

#comment out below command and run once. then comment it again and then run the whole file
#install.packages(packages)

#library call all the installed packages
lapply(packages, require, character.only = TRUE)
#############################################################
#############################################################


#data_dir = paste0("~/replication_package/maps/data/")
#gis_dir = paste0("~/replication_package/maps/gis/")
#result_dir = paste0("~/replication_package/maps/outputData/")

# read in the districtnames from the GIS files
OLD_OGR = sf::st_read(paste0(gis_dir,"westbengal_assembly_constituency_old.shp"))
NEW_OGR = sf::st_read(paste0(gis_dir,"westbengal_assembly_constituency_new.shp"))

OLD_OGR$new_gis_flag = 0
NEW_OGR$new_gis_flag = 1


ac.districts.old = data.table(fortify(OLD_OGR))
  ac.districts.old$new_ac_flag = 0
  ac.districts.old = ac.districts.old[,c("AC_NO", "AC_NAME", "new_ac_flag")]
  
  
ac.districts.new = data.table(fortify(NEW_OGR))
  ac.districts.new$new_ac_flag = 1
  ac.districts.new = ac.districts.new[,c("AC_NO", "AC_NAME", "new_ac_flag")]
  
  
ac.districts_gis = rbind(ac.districts.new, ac.districts.old)
ac.districts_gis$AC_NO = as.integer(ac.districts_gis$AC_NO)
ac.districts_gis$AC_NO_GIS = as.integer(ac.districts_gis$AC_NO)
ac.districts_gis$AC_NAME = as.character(ac.districts_gis$AC_NAME)
ac.districts_gis$AC_NAME_GIS_ORIG = ac.districts_gis$AC_NAME


#### read in the election result data files 
file.list = list.files(paste0(data_dir), pattern = "*.dta")

file.list.add = list.files(paste0(data_dir), pattern = "*.csv")

election.2004 = data.table(read.dta13(paste0(data_dir, file.list[1])))

# add in the missing voting data here -- can go back and add AC_TYPE data later I dont think we need it
election.2004_add = data.table(read.csv(paste0(data_dir, file.list.add[1])))
election.2004 = rbind(election.2004,election.2004_add)

  election.2004[, Year := 2004]
  election.2004[, AC_NAME := as.character(election.2004$old_ac)]
  election.2004[, AC_NO := election.2004$ac_number]
  election.2004[, new_ac_flag := 0]
  colnames(election.2004) <- gsub("*20[0-9][0-9]", '', colnames(election.2004))
  election.2004 = election.2004[, c("Year","AC_NO", "ac_type", "totvotes", "TotLeftVotes", "TotTmcIncVotes", "AC_NAME", "new_ac_flag")]
  
election.2006 = data.table(read.dta13(paste0(data_dir, file.list[2])))
  election.2006[, Year := 2006]
  election.2006[, AC_NAME := as.character(election.2006$old_ac)]
  election.2006[, AC_NO := election.2006$ac_number]
  election.2006[, new_ac_flag := 0]
  colnames(election.2006) <- gsub("*20[0-9][0-9]", '', colnames(election.2006))
  election.2006 = election.2006[, c("Year","AC_NO", "ac_type", "totvotes", "TotLeftVotes", "TotTmcIncVotes", "AC_NAME", "new_ac_flag")]
  
election.2009 = data.table(read.dta13(paste0(data_dir, file.list[3])))
# add in the missing voting data here -- can go back and add AC_TYPE data later I dont think we need it
election.2009_add = data.table(read.csv(paste0(data_dir, file.list.add[2])))
election.2009 = rbind(election.2009,election.2009_add)
  
  election.2009[, Year := 2009]
  election.2009[, AC_NAME := as.character(election.2009$new_ac)]
  election.2009[, AC_NO := election.2009$ac_number]
  election.2009[, new_ac_flag := 1]
  colnames(election.2009) <- gsub("*20[0-9][0-9]", '', colnames(election.2009))
  election.2009 = election.2009[, c("Year","AC_NO", "ac_type", "totvotes", "TotLeftVotes", "TotTmcIncVotes", "AC_NAME", "new_ac_flag")]
  
    
election.2011 = data.table(read.dta13(paste0(data_dir, file.list[4])))
  election.2011[, Year := 2011]
  election.2011[, AC_NAME := as.character(election.2011$new_ac)]
  election.2011[, AC_NO := election.2011$ac_number]
  election.2011[, new_ac_flag := 1]
  colnames(election.2011) <- gsub("*20[0-9][0-9]", '', colnames(election.2011))
  election.2011 = election.2011[, c("Year", "AC_NO", "ac_type", "totvotes", "TotLeftVotes", "TotTmcIncVotes", "AC_NAME", "new_ac_flag")]
  
election.years = as.numeric(c("2004", "2006", "2009", "2011"))

election.data.list = c("election.2004", "election.2006", "election.2009", "election.2011")
  

election.data.final = rbind(election.2004, election.2006, election.2009, election.2011)
election.data.final$AC_NAME_ELECT_ORIG = election.data.final$AC_NAME
election.data.final$AC_NO_ELECT = election.data.final$AC_NO
 

ac.districts_gis = data.frame(lapply(ac.districts_gis, 
                               function(v) {
                               if (is.character(v)) return(toupper(v))
                               else return(v)
                               }))

ac.districts_gis$AC_NAME = as.character(ac.districts_gis$AC_NAME)

ac.districts_gis$AC_NAME = gsub("\\(S[A-Z]\\)","", ac.districts_gis$AC_NAME, perl = F, fixed = F)
ac.districts_gis$AC_NAME = gsub(" $","", ac.districts_gis$AC_NAME, perl = F, fixed = F)


election.data.final = data.frame(lapply(election.data.final, 
                                        function(v) {
                                          if (is.character(v)) return(toupper(v))
                                          else return(v)
                                        }))
election.data.final$AC_NAME = as.character(election.data.final$AC_NAME)



assembly_constituency_join_check = data.table(left_join(election.data.final, ac.districts_gis, by = c("AC_NAME","new_ac_flag")))
assembly_constituency_join_check$MajorityVote_Left = ifelse(assembly_constituency_join_check$TotLeftVotes >= assembly_constituency_join_check$TotTmcIncVotes, 1, 0)


ac.final.data = assembly_constituency_join_check
for(i in 1:nrow(ac.final.data)){
  ac.final.data$MajorityVote_Left[i] = ifelse(ac.final.data$TotLeftVotes[i] >= ac.final.data$TotTmcIncVotes[i], 1, 0)
}

# rename AC_NO from GIS file to consistent name
ac.final.data$AC_NO = ac.final.data$AC_NO.x


final.data.2004 = ac.final.data[ which(Year == 2004),]
final.data.2006 = ac.final.data[ which(Year == 2006),]
final.data.2009 = ac.final.data[ which(Year == 2009),]
final.data.2011 = ac.final.data[ which(Year == 2011),]

# since interested in now joining the data to the shapefile, can use the AC_NO from the gis_join of the data and the AC_NO on the gis shapefile

### there are duplicate entries
final.data.2004[duplicated(final.data.2004$AC_NO) | duplicated(final.data.2004$AC_NO, fromLast = TRUE), ]
final.data.2006[duplicated(final.data.2006$AC_NO) | duplicated(final.data.2006$AC_NO, fromLast = TRUE), ]
final.data.2009[duplicated(final.data.2009$AC_NO) | duplicated(final.data.2009$AC_NO, fromLast = TRUE), ]
final.data.2011[duplicated(final.data.2011$AC_NO) | duplicated(final.data.2011$AC_NO, fromLast = TRUE), ]

### [COMMENT PART1] uncomment when creating ersi files
final.data.2004 = unique(x = final.data.2004, by='AC_NO')
final.data.2006 = unique(x = final.data.2006, by='AC_NO')
final.data.2009 = unique(x = final.data.2009, by='AC_NO')
final.data.2011 = unique(x = final.data.2011, by='AC_NO')
### END

final.data.2004$AC_NO = as.numeric(final.data.2004$AC_NO)
final.data.2006$AC_NO = as.numeric(final.data.2006$AC_NO)
final.data.2009$AC_NO = as.numeric(final.data.2009$AC_NO)
final.data.2011$AC_NO = as.numeric(final.data.2011$AC_NO)

final.data <- list(final.data.2004, final.data.2006, final.data.2009, final.data.2011)


OGR_2004 = OLD_OGR 
  OGR_2004 = left_join(OGR_2004, final.data.2004, by = "AC_NO")
OGR_2006 = OLD_OGR 
  OGR_2006 = left_join(OGR_2006, final.data.2006, by = "AC_NO")
OGR_2009 = NEW_OGR 
  OGR_2009 = left_join(OGR_2009, final.data.2009, by = "AC_NO")
OGR_2011 = NEW_OGR 
  OGR_2011 = left_join(OGR_2011, final.data.2011, by = "AC_NO")
  
OGR_2004.data = fortify(OGR_2004)  
OGR_2006.data = fortify(OGR_2006)  
OGR_2009.data = fortify(OGR_2009)  
OGR_2011.data = fortify(OGR_2011)  



OGR_2004_mod <- OGR_2004.data %>%
  filter(OGR_2004.data$Year == "2004")
write_csv(OGR_2004_mod, file = paste0(result_dir, "CompleteResults_2004", "ElectionGIS.csv"))

OGR_2006_mod <- OGR_2006.data %>%
  filter(OGR_2006.data$Year == "2006")
write_csv(OGR_2006_mod, file = paste0(result_dir, "CompleteResults_2006", "ElectionGIS.csv"))

OGR_2009_mod <- OGR_2009.data %>%
  filter(OGR_2009.data$Year == "2009")
write_csv(OGR_2009_mod, file = paste0(result_dir, "CompleteResults_2009", "ElectionGIS.csv"))

OGR_2011_mod <- OGR_2011.data %>%
  filter(OGR_2011.data$Year == "2011")
write_csv(OGR_2011_mod, file = paste0(result_dir, "CompleteResults_2011", "ElectionGIS.csv"))



