
*******************************************************************************************
*******************************************************************************************
* This do-file provides codes used for the village level anaylsis in the paper "How Do Voters Respond to Welfare vis-à-vis Public Good Programs? Theory and Evidence of Political Clientelism" by Pranab Bardhan, Sandip Mitra, Dilip Mookherjee, and Anusha Nath 

* List of tables and figures that can be replicated using this do-file:
*
* 		Table/Figure			  Line of code 
*	   ~~~~~~~~~~~~~~~~			~~~~~~~~~~~~~~~~
* 		Table 4:					  65
* 		Table 5:					  121 
* 		Table 6:					  212
* 		Table 7:					  321
* 		Table A3:					  463	
* 		Table A4:					  561 
* 		Table A5:					  657
* 		Table A6:					  748
* 		Table A7:					  949
* 		Table A8:					  1090
* 		Table A9: 					  1152
* 		Table A10:					  1241
* 		Table A11:					  1330
* 		Figure 2:  					  1421	
*		Figure 4:					  1469
* 		Figure 7: 					  1488
*		Figure A2: 					  1799
*		Figure A3: 					  1970

* Stata version: 					  Stata/MP 14.0 for Mac (64-bit Intel)
* Time to run this code: 			  294.366 seconds (4 minutes and 54.366 seconds)
* Output produced from this file is stored in the empty sub-folder called "replication_output"

*~~~~~~~~~~~~~~~~~
* INSTRUCTIONS: 
*~~~~~~~~~~~~~~~~~
* Change the directory path on line 58

set more off
*******************************************************************************************
*******************************************************************************************

* Installing required packages
    local ssc_packages "estout" "esttab" "coefplot" "boottest"
    if !missing("`ssc_packages'") {
        foreach pkg in "`ssc_packages'" {
        * install using ssc, but avoid re-installing if already present
            capture which `pkg'
            if _rc == 111 {                 
               dis "Installing `pkg'"
               quietly ssc install `pkg', replace
               }
        }
    }

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

* Change directory to where the replication folder is saved
*cd XXX


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
** Table 4
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"

keep village leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless  ///
		nonredistricted hc_aligned  hc_nonaligned lc_aligned lc_nonaligned ///
		leftgp03 leftpanchsam03 district
duplicates drop		
 
label variable leftpanchsam03 				"Left Panchayat Samiti"
label variable leftgp03 					"Left Dominated GP"
label variable leftwon2006 					"Left Won 2006 Assembly"
label variable delimcomm_member_assembly	"Delimitation Commission Member"
label variable scst_reservedconst_assem		"Seat Reserved for SC/ST"
label variable prophh_immig					"Proportion of HH Immigrated to Village Before 2004"
label variable prophh_scst					"Proportion of SC/ST HHs" 
label variable prophh_hindu					"Proportion of Hindu HHs" 
label variable prophh_occupcult				"Proportion Cultivators" 
label variable prophh_landless				"Proportion Landless in 2004"
 
 
eststo clear
eststo: reg   nonredistricted    ///
		leftgp03 leftpanchsam03 leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless , vce(cluster district) 				
estadd ysumm	 
eststo: reg   hc_aligned   ///
		leftgp03 leftpanchsam03 leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless , vce(cluster district) 							
estadd ysumm	
eststo: reg   hc_nonaligned   ///
		leftgp03 leftpanchsam03 leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless , vce(cluster district) 							
estadd ysumm
eststo: reg   lc_aligned    ///
		leftgp03 leftpanchsam03 leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless , vce(cluster district) 							
estadd ysumm	
eststo: reg   lc_nonaligned   ///
		leftgp03 leftpanchsam03 leftwon2006  scst_reservedconst_assem delimcomm_member_assembly ///
		prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless , vce(cluster district) 									
estadd ysumm	
esttab using "replication_output/Table4_output.tex", nocon ar2 label replace nogaps compress alignment(p{4cm}<{\centering}  ///
  		 p{4cm}<{\centering}) b(2) se(2) nonotes ///
		title(Predicting Redistricting) ///
		nostar ///
		mtitle("NON"  "HC * Aligned" "HC * nonaligned" "LC * Aligned" "LC * nonaligned") ///
		scalars("ymean Mean Dependent Variable" ) ///				
		order( leftpanchsam03 leftgp03 leftwon2006  delimcomm_member_assembly scst_reservedconst_assem  ///
			prophh_immig prophh_scst prophh_hindu prophh_occupcult prophh_landless) 	


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
** Table 5
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"


eststo clear
set more off
********************** DID
eststo: qui reg stdavg_private_vill post_morecomptt ///
	treatmorecompett  treatlesscompett post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui  reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
eststo: qui reg stdavg_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
set more off
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008  , vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
esttab using "replication_output/Table5_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep( post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) 


		
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table 6
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

set more off
eststo clear
*Employment
eststo: qui reg stdavg_emp_vill 	 ///
	post_morecomptt_alignedgpps	 ///
	post_morecomptt ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, 	seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, 	seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg stdavg_emp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
* Private benefits without employment
set more off
eststo: qui  reg stdavg_pvtnoemp_vill 	 ///
	post_morecomptt_alignedgpps	 ///
	post_morecomptt ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
set more off
eststo: qui  reg stdavg_pvtnoemp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
* Public benefits with water
set more off
eststo: qui  reg stdavg_publicwithwater_vill	 ///
	post_morecomptt_alignedgpps	 ///
	post_morecomptt ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
set more off
eststo: qui  reg stdavg_publicwithwater_vill	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
esttab using "replication_output/Table6_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep( post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) 
		

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Table 7
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

label variable placebopost_morecomptt			"Post × HC Redistricted"
label variable placebopost_morecomptt_aligned   "Post × HC Redistricted × Aligned"
label variable placebopost_lesscomptt			"Post × LC Redistricted"
label variable placebopost_lesscomptt_aligned   "Post × LC Redistricted × Aligned"

label variable placebotreatmorecomptt_post		"Post × HC Redistricted"
label variable placebotreatmore_aligned_post 	"Post × HC Redistricted × Aligned"
label variable placebotreatlesscomptt_post		"Post × LC Redistricted"
label variable placebotreatless_aligned_post 	"Post × LC Redistricted × Aligned"

set more off
eststo clear
set more off
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2005 & year<=2007, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
set more off
eststo: qui reg stdavg_public_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2005 & year<=2007, vce(cluster panchayatsamiti)		
estadd ysumm		
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Placebo shock (2004-2007)
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
eststo: qui reg stdavg_private_vill	///
	placebopost_morecomptt_aligned  placebopost_lesscomptt_aligned ///
	placebopost_morecomptt  placebopost_lesscomptt ///
	treatmorecompett  aligned_gpps  placebopost treatlesscompett ///
	placebopost_alignedgpps  morecomptt_alignedgpps lesscomptt_alignedgpps ///
	 delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2006   & new_ac!="BAGHMUNDI" & new_ac!="HEMTABAD" & new_ac!="SAINTHIA" , vce(cluster panchayatsamiti)	
estadd ysumm 
boottest placebopost_morecomptt_aligned=placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt=placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg stdavg_publicadj_vill ///
	placebopost_morecomptt_aligned  placebopost_lesscomptt_aligned ///
	placebopost_morecomptt  placebopost_lesscomptt ///
	treatmorecompett  aligned_gpps  placebopost treatlesscompett ///
	placebopost_alignedgpps  morecomptt_alignedgpps lesscomptt_alignedgpps ///
	 delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2006   & new_ac!="BAGHMUNDI" & new_ac!="HEMTABAD" & new_ac!="SAINTHIA" , vce(cluster panchayatsamiti)	
estadd ysumm 	
boottest placebopost_morecomptt_aligned=placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt=placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Placebo treatment
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg stdavg_private_vill 	///
	placebotreatmore_aligned_post placebotreatless_aligned_post  ///
	placebotreatmorecomptt_post  placebotreatlesscomptt_post ///
	placebotreatmorecomptt placebotreatlesscomptt  aligned_gpps  post ///
	post_alignedgpps 	placebotreatmorecomptt_aligned placebotreatlesscomptt_aligned ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm 
boottest placebotreatmore_aligned_post = placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post = placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmore_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg stdavg_publicadj_vill  ///
	placebotreatmore_aligned_post placebotreatless_aligned_post  ///
	placebotreatmorecomptt_post  placebotreatlesscomptt_post ///
	placebotreatmorecomptt placebotreatlesscomptt  aligned_gpps  post ///
	post_alignedgpps 	placebotreatmorecomptt_aligned placebotreatlesscomptt_aligned ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm 	
boottest placebotreatmore_aligned_post = placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post = placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmore_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
esttab using "replication_output/Table7_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Robustness Tests)  ///
		mtitle("Main_pvt" "Main_pub" "PlaceboShock_pvt" "PlaceboShock_pub" "PlaceboTreat_pvt" "PlaceboTreat_pub" ) /// 
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
			 post_morecomptt post_lesscomptt ///
			 placebopost_morecomptt_aligned  placebopost_morecomptt ///
			 placebopost_lesscomptt_aligned  placebopost_lesscomptt ///
			 placebotreatmore_aligned_post placebotreatmorecomptt_post  ///
			 placebotreatless_aligned_post placebotreatlesscomptt_post)	 ///			
		order(post_morecomptt post_morecomptt_alignedgpps ///
			  post_lesscomptt post_lesscomptt_alignedgpps  ///
			  placebopost_morecomptt  placebopost_morecomptt_aligned   ///
			  placebopost_lesscomptt placebopost_lesscomptt_aligned   ///
			  placebotreatmorecomptt_post placebotreatmore_aligned_post   ///
			  placebotreatlesscomptt_post placebotreatless_aligned_post )


			 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A3
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"
label variable treatlesscompett 				"LC Redistricted"
label variable treatmorecompett 				"HC Redistricted"
label variable aligned_gpps  					"Aligned"
label variable post 							"Post"
label variable post_alignedgpps  				"Post x Aligned"
label variable morecomptt_alignedgpps			"HC Redistricted x Aligned"
label variable lesscomptt_alignedgpps			"LC Redistricted x Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg stdavg_private_vill post_morecomptt ///
	treatmorecompett  post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
eststo: qui  reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
********************** DDD: With Alignment variables
eststo: qui reg stdavg_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)			
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)	
********************** DDD: With LC treatment groups
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA3_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///  		
		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps  ///
			treatlesscompett treatmorecompett aligned_gpps  post ///
			post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ///
			treatlesscompett treatmorecompett aligned_gpps  post ///
			post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps)
			 

*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A4
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg stdavg_private_vill post_morecomptt ///
	treatmorecompett  post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	timetrend_hc_aligned  timetrend_hc_nonaligned  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///	
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
eststo: qui reg stdavg_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///	 
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///	 
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///	
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
set more off							
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///	
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA4_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///  		
		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep( post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps)		
		


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A5
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 		
		
clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg prophh_private_vill post_morecomptt ///
	treatmorecompett  treatlesscompett post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
eststo: qui reg prophh_publicadj_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
********************** DDD: With Alignment variables
eststo: qui reg prophh_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg prophh_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg prophh_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
set more off
eststo: qui reg prophh_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA5_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///  		
		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep( post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps)	
				
			
			
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A6
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.	


clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

*** Panel [a] 

set more off
eststo clear
*employment
eststo: qui reg stdavg_emp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
*irdp     
eststo: qui reg stdavg_irdp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
* Minikit
eststo: qui reg stdav_minikit_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
*Ration Card
eststo: qui reg stdavg_ration_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///		
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
* Drinking Water 
eststo: qui reg stdavg_water_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
* Housing and toilet
eststo: qui reg stdavg_housetoilet_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///		
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
esttab using "replication_output/TableA6a_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Examining Effect of Competition and Alignment by Type of Benefits)  ///
		mtitle("Emp" "Credit" "Minikit" "BPL" "Water" "Housing") ///
		nostar ///	
		keep(post_morecomptt post_morecomptt_alignedgpps  post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps  post_lesscomptt post_lesscomptt_alignedgpps )

		
*** Panel [b]
set more off
eststo clear
*employment
eststo: qui reg prophh_emp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
*irdp     
eststo: qui reg prophh_irdp_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
* Minikit
eststo: qui reg prophh_minikit_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
*Ration Card
eststo: qui reg prophh_ration_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///		
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
* Drinking Water 
eststo: qui reg prophh_water_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///			
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
* Housing and toilet
eststo: qui reg prophh_housetoilet_vill 	 ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  districtdum* yeardum*  ///
	timetrend_hc_aligned  timetrend_hc_nonaligned timetrend_lc_aligned timetrend_lc_nonaligned ///		
	if year>=2003 & year<2012, vce(cluster panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA6b_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Examining Effect of Competition and Alignment by Type of Benefits)  ///
		mtitle("Emp" "Credit" "Minikit" "BPL" "Water" "Housing") ///
		nostar ///	
		keep(post_morecomptt post_morecomptt_alignedgpps  post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps  post_lesscomptt post_lesscomptt_alignedgpps )
		


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A7
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 		
		
		
clear 
use "VillageYear_Data.dta"	

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

label variable placebopost_morecomptt			"Post × HC Redistricted"
label variable placebopost_morecomptt_aligned   "Post × HC Redistricted × Aligned"
label variable placebopost_lesscomptt			"Post × LC Redistricted"
label variable placebopost_lesscomptt_aligned   "Post × LC Redistricted × Aligned"

label variable placebotreatmorecomptt_post		"Post × HC Redistricted"
label variable placebotreatmore_aligned_post 	"Post × HC Redistricted × Aligned"
label variable placebotreatlesscomptt_post		"Post × LC Redistricted"
label variable placebotreatless_aligned_post 	"Post × LC Redistricted × Aligned"
			
eststo clear
set more off
eststo: qui reg prophh_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2005 & year<=2007, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
set more off
eststo: qui reg prophh_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2005 & year<=2007, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
set more off
* Placebo shock (2004-2007)
eststo: qui reg prophh_private_vill	///
	placebopost_morecomptt_aligned  placebopost_lesscomptt_aligned ///
	placebopost_morecomptt  placebopost_lesscomptt ///
	treatmorecompett  aligned_gpps  placebopost treatlesscompett ///
	placebopost_alignedgpps  morecomptt_alignedgpps lesscomptt_alignedgpps ///
	 delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2006, vce(cluster panchayatsamiti)	
estadd ysumm 
boottest placebopost_morecomptt_aligned=placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt=placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg prophh_publicadj_vill ///
	placebopost_morecomptt_aligned  placebopost_lesscomptt_aligned ///
	placebopost_morecomptt  placebopost_lesscomptt ///
	treatmorecompett  aligned_gpps  placebopost treatlesscompett ///
	placebopost_alignedgpps  morecomptt_alignedgpps lesscomptt_alignedgpps ///
	 delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2006, vce(cluster panchayatsamiti)	
estadd ysumm 	
boottest placebopost_morecomptt_aligned=placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt=placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt_aligned, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebopost_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
* Placebo treatment
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg prophh_private_vill 	///
	placebotreatmore_aligned_post placebotreatless_aligned_post  ///
	placebotreatmorecomptt_post  placebotreatlesscomptt_post ///
	placebotreatmorecomptt placebotreatlesscomptt  aligned_gpps  post ///
	post_alignedgpps 	placebotreatmorecomptt_aligned placebotreatlesscomptt_aligned ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm 
boottest placebotreatmore_aligned_post = placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post = placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmore_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
*~.~.~.~.~.~.~.~.~.~.~.
set more off
eststo: qui reg prophh_publicadj_vill  ///
	placebotreatmore_aligned_post placebotreatless_aligned_post  ///
	placebotreatmorecomptt_post  placebotreatlesscomptt_post ///
	placebotreatmorecomptt placebotreatlesscomptt  aligned_gpps  post ///
	post_alignedgpps 	placebotreatmorecomptt_aligned placebotreatlesscomptt_aligned ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)
estadd ysumm 	
boottest placebotreatmore_aligned_post = placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post = placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmore_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatmorecomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatless_aligned_post, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest placebotreatlesscomptt_post, seed(7)	reps(1000) cluster(panchayatsamiti)
esttab using "replication_output/TableA7_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Robustness Tests)  ///
		nomtitle /// 
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ///
			 placebopost_morecomptt_aligned  placebopost_morecomptt ///
			 placebopost_lesscomptt_aligned  placebopost_lesscomptt ///
			 placebotreatmore_aligned_post   placebotreatmorecomptt_post  ///
			 placebotreatless_aligned_post   placebotreatlesscomptt_post)	 ///			
		order(post_morecomptt post_morecomptt_alignedgpps ///
			  post_lesscomptt post_lesscomptt_alignedgpps  ///
			  placebopost_morecomptt  placebopost_morecomptt_aligned   ///
			  placebopost_lesscomptt placebopost_lesscomptt_aligned   ///
			  placebotreatmorecomptt_post placebotreatmore_aligned_post   ///
			  placebotreatlesscomptt_post placebotreatless_aligned_post )
	

	
			
			
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A8
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"	

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"		 
			
eststo clear
********************** DID
set more off
eststo: qui  reg stdavg_public_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
set more off
eststo: qui reg stdavg_public_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups		
set more off
eststo: qui reg stdavg_public_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA8_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///  		
		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps)
					
			
			
			
			 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A9
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg stdavg_private_vill post_morecomptt ///
	treatmorecompett  treatlesscompett post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui  reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
eststo: qui reg stdavg_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
set more off
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2011  , vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
esttab using "replication_output/TableA9_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) 

	 
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A10
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg stdavg_private_vill post_morecomptt ///
	treatmorecompett  treatlesscompett post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=1998 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui  reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=1998 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
eststo: qui reg stdavg_private_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=1998 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=1998 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg stdavg_private_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=1998 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
set more off
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=1998 & year<=2008  , vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
esttab using "replication_output/TableA10_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///
  		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Robustness: Including Period 1998-2008)  ///
		nomtitle ///
		nostar ///
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps ) 
	
	
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Table A11
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

label variable post_morecomptt 					"Post × HC Redistricted"
label variable post_morecomptt_alignedgpps 		"Post × HC Redistricted × Aligned"
label variable post_lesscomptt 					"Post × LC Redistricted"
label variable post_lesscomptt_alignedgpps		"Post × LC Redistricted × Aligned"

eststo clear
set more off
********************** DID
eststo: qui reg stdavg_privatev2_vill post_morecomptt ///
	treatmorecompett  treatlesscompett post ///
	 delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
eststo: qui  reg stdavg_publicadj_vill 	post_morecomptt ///
	treatmorecompett treatlesscompett  post ///
	delimcomm_member_assembly  villagedum* yeardum*  ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With Alignment variables
eststo: qui reg stdavg_privatev2_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum*  yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)	
eststo: qui reg stdavg_publicadj_vill 	post_morecomptt_alignedgpps  ///
	treatmorecompett treatlesscompett aligned_gpps  post ///
	post_alignedgpps  post_morecomptt	morecomptt_alignedgpps ///
	 delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)	
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt,seed(7) reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
********************** DDD: With LC treatment groups
set more off
eststo: qui reg stdavg_privatev2_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
set more off
eststo: qui reg stdavg_publicadj_vill ///
	post_morecomptt_alignedgpps	post_lesscomptt_alignedgpps  ///
	post_morecomptt post_lesscomptt ///
	treatlesscompett treatmorecompett aligned_gpps  post ///
	post_alignedgpps  morecomptt_alignedgpps	lesscomptt_alignedgpps ///
	delimcomm_member_assembly  villagedum* yeardum* ///
	if year>=2004 & year<=2008, vce(cluster panchayatsamiti)		
estadd ysumm	
boottest post_morecomptt_alignedgpps+ post_morecomptt=0, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt_alignedgpps=post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt=post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)	
boottest post_morecomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt_alignedgpps, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_morecomptt, seed(7)	reps(1000) cluster(panchayatsamiti)
boottest post_lesscomptt, seed(7)	reps(1000) cluster(panchayatsamiti)		
esttab using "replication_output/TableA11_output.tex", nocon ar2 label replace nogaps compress alignment(p{1.5cm}<{\centering}  ///  		
		p{1.5cm}<{\centering} p{1.5cm}<{\centering} p{1.5cm}<{\centering}) b(2) se(2) nonotes ///
		title(Diff-in-Diff: Effect of Competition and Alignment on Benefits Distributed)  ///
		nomtitle ///
		nostar ///	
		scalars("ymean Mean Annual Per HH Benefits" "ysd SD Annual Per HH Benefits") ///		
		keep(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps) ///		
		order(post_morecomptt post_morecomptt_alignedgpps post_lesscomptt post_lesscomptt_alignedgpps)		
		
	
			 
			
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
*	Figure 2
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"
keep if year==2006
keep  panchayatsamiti village grampanchayat treatmorecompett treatlesscompett leftgp03  leftpanchsam03
duplicates drop

log using "replication_output/Figure2_output", replace

*------------------------------------------------------------
*** Villages
* Panchayat Samiti Left Majority and Gram Panchayat Left Majority
count if leftpanchsam03==1 & leftgp03==1
* Panchayat Samiti Left Majority and Gram Panchayat TMC/INC Majority
count if leftpanchsam03==1 & leftgp03==0
* Panchayat Samiti TMC/INC Majority  and Gram Panchayat Left Majority
count if leftpanchsam03==0 & leftgp03==1
* Panchayat Samiti TMC/INC Majority  and Gram Panchayat TMC/INC Majority
count if leftpanchsam03==0 & leftgp03==0

*------------------------------------------------------------
*** Gram Panchayats
keep panchayatsamiti grampanchayat leftgp03 leftpanchsam03
duplicates drop
* Panchayat Samiti Left Majority and Gram Panchayat Left Majority
count if leftpanchsam03==1 & leftgp03==1
* Panchayat Samiti Left Majority and Gram Panchayat TMC/INC Majority
count if leftpanchsam03==1 & leftgp03==0
* Panchayat Samiti TMC/INC Majority  and Gram Panchayat Left Majority
count if leftpanchsam03==0 & leftgp03==1
* Panchayat Samiti TMC/INC Majority  and Gram Panchayat TMC/INC Majority
count if leftpanchsam03==0 & leftgp03==0

*------------------------------------------------------------
*** Panchayat Samiti
keep panchayatsamiti leftpanchsam03
duplicates drop
* Panchayat Samiti Left Majority 
count if leftpanchsam03==1 
* Panchayat Samiti TMC/INC Majority
count if leftpanchsam03==0

log close


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
*	Figure 4
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

clear 
use "VillageYear_Data.dta"

graph twoway (scatter victmargin2006_2011bnd victmargin2006 if victmargin2006_2011bnd<victmargin2006, msymbol(Dh) mcolor(gs10) ylabel(0(0.2)0.8)) ///
		(scatter victmargin2006_2011bnd victmargin2006 if victmargin2006_2011bnd==victmargin2006, msymbol(+) mcolor(gs10) ylabel(0(0.2)0.8)) ///	
			(scatter victmargin2006_2011bnd victmargin2006  if victmargin2006_2011bnd>victmargin2006, msymbol(O) mcolor(gs10) ylabel(0(0.2)0.8) ///
			ytitle(Victory Margin in 2006 (New Boundaries), height(7)) xtitle(Victory Margin in 2006 (Old Boundaries), height(7)) graphregion(color(white)) ///
			legend(label(1 "HC Redistricted GPs") label(2 "Not Redistricted GPs") label(3 "LC Redistricted GPs") region(lwidth(none)) rows(1) pos(6))) 
graph export "replication_output/Figure4_output.pdf", as(pdf) name("Graph")	replace		



*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.
*	Figure 7
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.

*****	 2004-2011 in High competition 
*--------------------------------------------------------

clear 
use "VillageYear_Data.dta"

gen	morecomptt_alignedgpps_tp5=morecomptt_alignedgpps*yeardum18
gen	morecomptt_alignedgpps_tp4=morecomptt_alignedgpps*yeardum17			
gen	morecomptt_alignedgpps_tp3=morecomptt_alignedgpps*yeardum16			
gen	morecomptt_alignedgpps_tp2=morecomptt_alignedgpps*yeardum15
gen	morecomptt_alignedgpps_tp1=morecomptt_alignedgpps*yeardum14	
gen	morecomptt_alignedgpps_t0=morecomptt_alignedgpps*yeardum13
gen	morecomptt_alignedgpps_tm1=morecomptt_alignedgpps*yeardum12
gen	morecomptt_alignedgpps_tm2=morecomptt_alignedgpps*yeardum11

gen	lesscomptt_alignedgpps_tp5=lesscomptt_alignedgpps*yeardum18
gen	lesscomptt_alignedgpps_tp4=lesscomptt_alignedgpps*yeardum17			
gen	lesscomptt_alignedgpps_tp3=lesscomptt_alignedgpps*yeardum16
gen	lesscomptt_alignedgpps_tp2=lesscomptt_alignedgpps*yeardum15
gen	lesscomptt_alignedgpps_tp1=lesscomptt_alignedgpps*yeardum14	
gen	lesscomptt_alignedgpps_t0=lesscomptt_alignedgpps*yeardum13
gen	lesscomptt_alignedgpps_tm1=lesscomptt_alignedgpps*yeardum12
gen	lesscomptt_alignedgpps_tm2=lesscomptt_alignedgpps*yeardum11

gen morecomptt_nonaligned= treatmorecompett* nonaligned
gen lesscomptt_nonaligned= treatlesscompett* nonaligned

gen	morecomptt_nonaligned_tp5=morecomptt_nonaligned*yeardum18
gen	morecomptt_nonaligned_tp4=morecomptt_nonaligned*yeardum17
gen	morecomptt_nonaligned_tp3=morecomptt_nonaligned*yeardum16
gen	morecomptt_nonaligned_tp2=morecomptt_nonaligned*yeardum15
gen	morecomptt_nonaligned_tp1=morecomptt_nonaligned*yeardum14	
gen	morecomptt_nonaligned_t0=morecomptt_nonaligned*yeardum13
gen	morecomptt_nonaligned_tm1=morecomptt_nonaligned*yeardum12
gen	morecomptt_nonaligned_tm2=morecomptt_nonaligned*yeardum11


gen	lesscomptt_nonaligned_tp5=lesscomptt_nonaligned*yeardum18
gen	lesscomptt_nonaligned_tp4=lesscomptt_nonaligned*yeardum17
gen	lesscomptt_nonaligned_tp3=lesscomptt_nonaligned*yeardum16
gen	lesscomptt_nonaligned_tp2=lesscomptt_nonaligned*yeardum15
gen	lesscomptt_nonaligned_tp1=lesscomptt_nonaligned*yeardum14	
gen	lesscomptt_nonaligned_t0=lesscomptt_nonaligned*yeardum13
gen	lesscomptt_nonaligned_tm1=lesscomptt_nonaligned*yeardum12
gen	lesscomptt_nonaligned_tm2=lesscomptt_nonaligned*yeardum11

gen zero=0
label variable zero "2006"	

label variable  morecomptt_alignedgpps_tm2 "2004"
label variable  morecomptt_alignedgpps_tm1 "2005"
label variable  morecomptt_alignedgpps_t0  "2006"
label variable  morecomptt_alignedgpps_tp1 "2007"
label variable  morecomptt_alignedgpps_tp2 "2008"
label variable  morecomptt_alignedgpps_tp3 "2009"
label variable  morecomptt_alignedgpps_tp4 "2010"
label variable  morecomptt_alignedgpps_tp5 "2011"

label variable  lesscomptt_alignedgpps_tm2 "2004"
label variable  lesscomptt_alignedgpps_tm1 "2005"
label variable  lesscomptt_alignedgpps_t0  "2006"
label variable  lesscomptt_alignedgpps_tp1 "2007"
label variable  lesscomptt_alignedgpps_tp2 "2008"
label variable  lesscomptt_alignedgpps_tp3 "2009"
label variable  lesscomptt_alignedgpps_tp4 "2010"
label variable  lesscomptt_alignedgpps_tp5 "2011"

label variable  morecomptt_nonaligned_tm2 "2004"
label variable  morecomptt_nonaligned_tm1 "2005"
label variable  morecomptt_nonaligned_t0  "2006"
label variable  morecomptt_nonaligned_tp1 "2007"
label variable  morecomptt_nonaligned_tp2 "2008"
label variable  morecomptt_nonaligned_tp3 "2009"
label variable  morecomptt_nonaligned_tp4 "2010"
label variable  morecomptt_nonaligned_tp5 "2011"

label variable  lesscomptt_nonaligned_tm2 "2004"
label variable  lesscomptt_nonaligned_tm1 "2005"
label variable  lesscomptt_nonaligned_t0  "2006"
label variable  lesscomptt_nonaligned_tp1 "2007"
label variable  lesscomptt_nonaligned_tp2 "2008"
label variable  lesscomptt_nonaligned_tp3 "2009"
label variable  lesscomptt_nonaligned_tp4 "2010"
label variable  lesscomptt_nonaligned_tp5 "2011"

eststo clear
eststo: reg stdavg_private_vill 	 ///
	morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 ///
	morecomptt_alignedgpps_tp2 morecomptt_alignedgpps_tp1 zero  morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1  ///
	  morecomptt_alignedgpps	treatmorecompett aligned_gpps ///
	delimcomm_member_assembly villagedum*  ///
	if year>=2004 & year<=2011 , vce(cluster panchayatsamiti)
estimates store estpvt
eststo: reg stdavg_publicadj_vill 	 ///
	morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 ///
	morecomptt_alignedgpps_tp2 morecomptt_alignedgpps_tp1 zero  morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1  ///
	  morecomptt_alignedgpps	treatmorecompett aligned_gpps ///
	delimcomm_member_assembly villagedum*  ///
	if year>=2004 & year<=2011 , vce(cluster panchayatsamiti)
estimates store estpub
drop morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 morecomptt_alignedgpps_tp2 morecomptt_alignedgpps_tp1 ///
	morecomptt_alignedgpps_t0  morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1  aligned_gpps morecomptt_alignedgpps
gen morecomptt_alignedgpps_tp5=morecomptt_nonaligned_tp5
gen morecomptt_alignedgpps_tp4=morecomptt_nonaligned_tp4
gen morecomptt_alignedgpps_tp3=morecomptt_nonaligned_tp3
gen morecomptt_alignedgpps_tp2=morecomptt_nonaligned_tp2
gen morecomptt_alignedgpps_tp1=morecomptt_nonaligned_tp1
gen morecomptt_alignedgpps_t0=morecomptt_nonaligned_t0
gen morecomptt_alignedgpps_tm2=morecomptt_nonaligned_tm2
gen morecomptt_alignedgpps_tm1=morecomptt_nonaligned_tm1
gen aligned_gpps=nonaligned
gen morecomptt_alignedgpps=morecomptt_nonaligned	  
label variable  morecomptt_alignedgpps_tm2 "2004"
label variable  morecomptt_alignedgpps_tm1 "2005"
label variable  morecomptt_alignedgpps_t0  "2006"
label variable  morecomptt_alignedgpps_tp1 "2007"
label variable  morecomptt_alignedgpps_tp2 "2008"
label variable  morecomptt_alignedgpps_tp3 "2009"
label variable  morecomptt_alignedgpps_tp4 "2010"
label variable  morecomptt_alignedgpps_tp5 "2011"
eststo: reg stdavg_private_vill 	 ///
	morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 ///
	morecomptt_alignedgpps_tp2 morecomptt_alignedgpps_tp1 zero  morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1  ///
	morecomptt_alignedgpps	treatmorecompett aligned_gpps ///
	delimcomm_member_assembly villagedum*  ///
	if year>=2004 & year<=2011 , vce(cluster panchayatsamiti)
estimates store estpvt2
eststo: reg stdavg_publicadj_vill 	 ///
	morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 ///
	morecomptt_alignedgpps_tp2 morecomptt_alignedgpps_tp1 zero  morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1  ///
	  morecomptt_alignedgpps	treatmorecompett aligned_gpps ///
	delimcomm_member_assembly villagedum*  ///
	if year>=2004 & year<=2011 , vce(cluster panchayatsamiti)
estimates store estpub2
coefplot (estpvt, label(HC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpvt2, label(HC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(	morecomptt_alignedgpps_tp5 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp3 /// 
				morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1 zero  morecomptt_alignedgpps_tp1 zero morecomptt_alignedgpps_tp2) ///
		order(morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1 zero  morecomptt_alignedgpps_tp1  morecomptt_alignedgpps_tp2 ///
				morecomptt_alignedgpps_tp3 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp5) ///	
		yline(0) omitted ci(90 myci) ciopts(lcol(gray)) ///			  
		title(Private Benefits - High Competition) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets
graph export "replication_output/Figure7a1_output.pdf", as(pdf) name("Graph") replace
coefplot (estpub, label(HC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpub2, label(HC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1 zero  morecomptt_alignedgpps_tp1 zero morecomptt_alignedgpps_tp2 ///
				morecomptt_alignedgpps_tp3 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp5) ///	
		order(morecomptt_alignedgpps_tm2 morecomptt_alignedgpps_tm1 zero  morecomptt_alignedgpps_tp1  morecomptt_alignedgpps_tp2 ///	
				morecomptt_alignedgpps_tp3 morecomptt_alignedgpps_tp4 morecomptt_alignedgpps_tp5) ///	
		yline(0) omitted ci(90 myci) ///			  
		title(Public Benefits - High Competition) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets
graph export "replication_output/Figure7b1_output.pdf", as(pdf) name("Graph") replace



*****		2004-2011 in Low competition	 
*--------------------------------------------------------

clear 
use "VillageYear_Data.dta"

gen	morecomptt_alignedgpps_tp5=morecomptt_alignedgpps*yeardum18
gen	morecomptt_alignedgpps_tp4=morecomptt_alignedgpps*yeardum17			
gen	morecomptt_alignedgpps_tp3=morecomptt_alignedgpps*yeardum16			
gen	morecomptt_alignedgpps_tp2=morecomptt_alignedgpps*yeardum15
gen	morecomptt_alignedgpps_tp1=morecomptt_alignedgpps*yeardum14	
gen	morecomptt_alignedgpps_t0=morecomptt_alignedgpps*yeardum13
gen	morecomptt_alignedgpps_tm1=morecomptt_alignedgpps*yeardum12
gen	morecomptt_alignedgpps_tm2=morecomptt_alignedgpps*yeardum11

gen	lesscomptt_alignedgpps_tp5=lesscomptt_alignedgpps*yeardum18
gen	lesscomptt_alignedgpps_tp4=lesscomptt_alignedgpps*yeardum17			
gen	lesscomptt_alignedgpps_tp3=lesscomptt_alignedgpps*yeardum16
gen	lesscomptt_alignedgpps_tp2=lesscomptt_alignedgpps*yeardum15
gen	lesscomptt_alignedgpps_tp1=lesscomptt_alignedgpps*yeardum14	
gen	lesscomptt_alignedgpps_t0=lesscomptt_alignedgpps*yeardum13
gen	lesscomptt_alignedgpps_tm1=lesscomptt_alignedgpps*yeardum12
gen	lesscomptt_alignedgpps_tm2=lesscomptt_alignedgpps*yeardum11

gen morecomptt_nonaligned= treatmorecompett* nonaligned
gen lesscomptt_nonaligned= treatlesscompett* nonaligned

gen	morecomptt_nonaligned_tp5=morecomptt_nonaligned*yeardum18
gen	morecomptt_nonaligned_tp4=morecomptt_nonaligned*yeardum17
gen	morecomptt_nonaligned_tp3=morecomptt_nonaligned*yeardum16
gen	morecomptt_nonaligned_tp2=morecomptt_nonaligned*yeardum15
gen	morecomptt_nonaligned_tp1=morecomptt_nonaligned*yeardum14	
gen	morecomptt_nonaligned_t0=morecomptt_nonaligned*yeardum13
gen	morecomptt_nonaligned_tm1=morecomptt_nonaligned*yeardum12
gen	morecomptt_nonaligned_tm2=morecomptt_nonaligned*yeardum11


gen	lesscomptt_nonaligned_tp5=lesscomptt_nonaligned*yeardum18
gen	lesscomptt_nonaligned_tp4=lesscomptt_nonaligned*yeardum17
gen	lesscomptt_nonaligned_tp3=lesscomptt_nonaligned*yeardum16
gen	lesscomptt_nonaligned_tp2=lesscomptt_nonaligned*yeardum15
gen	lesscomptt_nonaligned_tp1=lesscomptt_nonaligned*yeardum14	
gen	lesscomptt_nonaligned_t0=lesscomptt_nonaligned*yeardum13
gen	lesscomptt_nonaligned_tm1=lesscomptt_nonaligned*yeardum12
gen	lesscomptt_nonaligned_tm2=lesscomptt_nonaligned*yeardum11

gen zero=0
label variable zero "2006"	

label variable  morecomptt_alignedgpps_tm2 "2004"
label variable  morecomptt_alignedgpps_tm1 "2005"
label variable  morecomptt_alignedgpps_t0  "2006"
label variable  morecomptt_alignedgpps_tp1 "2007"
label variable  morecomptt_alignedgpps_tp2 "2008"
label variable  morecomptt_alignedgpps_tp3 "2009"
label variable  morecomptt_alignedgpps_tp4 "2010"
label variable  morecomptt_alignedgpps_tp5 "2011"

label variable  lesscomptt_alignedgpps_tm2 "2004"
label variable  lesscomptt_alignedgpps_tm1 "2005"
label variable  lesscomptt_alignedgpps_t0  "2006"
label variable  lesscomptt_alignedgpps_tp1 "2007"
label variable  lesscomptt_alignedgpps_tp2 "2008"
label variable  lesscomptt_alignedgpps_tp3 "2009"
label variable  lesscomptt_alignedgpps_tp4 "2010"
label variable  lesscomptt_alignedgpps_tp5 "2011"

label variable  morecomptt_nonaligned_tm2 "2004"
label variable  morecomptt_nonaligned_tm1 "2005"
label variable  morecomptt_nonaligned_t0  "2006"
label variable  morecomptt_nonaligned_tp1 "2007"
label variable  morecomptt_nonaligned_tp2 "2008"
label variable  morecomptt_nonaligned_tp3 "2009"
label variable  morecomptt_nonaligned_tp4 "2010"
label variable  morecomptt_nonaligned_tp5 "2011"

label variable  lesscomptt_nonaligned_tm2 "2004"
label variable  lesscomptt_nonaligned_tm1 "2005"
label variable  lesscomptt_nonaligned_t0  "2006"
label variable  lesscomptt_nonaligned_tp1 "2007"
label variable  lesscomptt_nonaligned_tp2 "2008"
label variable  lesscomptt_nonaligned_tp3 "2009"
label variable  lesscomptt_nonaligned_tp4 "2010"
label variable  lesscomptt_nonaligned_tp5 "2011"


 
eststo clear		
eststo: reg stdavg_private_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpvtLC		
eststo: reg stdavg_publicadj_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpubLC		
drop 	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
		lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1  lesscomptt_alignedgpps  aligned_gpps
gen lesscomptt_alignedgpps_tp5= lesscomptt_nonaligned_tp5
gen lesscomptt_alignedgpps_tp4= lesscomptt_nonaligned_tp4		
gen lesscomptt_alignedgpps_tp3= lesscomptt_nonaligned_tp3		
gen lesscomptt_alignedgpps_tp2= lesscomptt_nonaligned_tp2 
gen lesscomptt_alignedgpps_tp1= lesscomptt_nonaligned_tp1 
gen lesscomptt_alignedgpps_tm2= lesscomptt_nonaligned_tm2
gen lesscomptt_alignedgpps_tm1= lesscomptt_nonaligned_tm1  
gen lesscomptt_alignedgpps= lesscomptt_nonaligned  
gen aligned_gpps= nonaligned
label variable  lesscomptt_alignedgpps_tm2 "2004"
label variable  lesscomptt_alignedgpps_tm1 "2005"
label variable  lesscomptt_alignedgpps_t0  "2006"
label variable  lesscomptt_alignedgpps_tp1 "2007"
label variable  lesscomptt_alignedgpps_tp2 "2008"
label variable  lesscomptt_alignedgpps_tp3 "2009"
label variable  lesscomptt_alignedgpps_tp4 "2010"
label variable  lesscomptt_alignedgpps_tp5 "2011"
eststo: reg stdavg_private_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpvtLC_v2		
eststo: reg stdavg_publicadj_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=2004 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpubLC_v2		
coefplot (estpvtLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpvtLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1 zero lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///
		order(lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///	
		yline(0) omitted ci(90 myci) ///			  
		title(Private Benefits - Low Competition) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets
graph export "replication_output/Figure7a2_output.pdf", as(pdf) name("Graph") replace		
coefplot (estpubLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpubLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1 zero lesscomptt_alignedgpps_tp2 ///
					lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///
		order(lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///	
		yline(0) omitted ci(90 myci) ///			  
		title(Public Benefits - Low Competition) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets		
graph export "replication_output/Figure7b2_output.pdf", as(pdf) name("Graph") replace		


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.		
*** Figure A2
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"		
		

gen	lesscomptt_alignedgpps_tp5=lesscomptt_alignedgpps*yeardum18
gen	lesscomptt_alignedgpps_tp4=lesscomptt_alignedgpps*yeardum17			
gen	lesscomptt_alignedgpps_tp3=lesscomptt_alignedgpps*yeardum16
gen	lesscomptt_alignedgpps_tp2=lesscomptt_alignedgpps*yeardum15
gen	lesscomptt_alignedgpps_tp1=lesscomptt_alignedgpps*yeardum14	
gen	lesscomptt_alignedgpps_t0=lesscomptt_alignedgpps*yeardum13
gen	lesscomptt_alignedgpps_tm1=lesscomptt_alignedgpps*yeardum12
gen	lesscomptt_alignedgpps_tm2=lesscomptt_alignedgpps*yeardum11
gen	lesscomptt_alignedgpps_tm3=lesscomptt_alignedgpps*yeardum10
gen	lesscomptt_alignedgpps_tm4=lesscomptt_alignedgpps*yeardum9
gen	lesscomptt_alignedgpps_tm5=lesscomptt_alignedgpps*yeardum8
gen	lesscomptt_alignedgpps_tm6=lesscomptt_alignedgpps*yeardum7
gen	lesscomptt_alignedgpps_tm7=lesscomptt_alignedgpps*yeardum6
gen	lesscomptt_alignedgpps_tm8=lesscomptt_alignedgpps*yeardum5
		
gen lesscomptt_nonaligned= treatlesscompett* nonaligned

gen	lesscomptt_nonaligned_tp5=lesscomptt_nonaligned*yeardum18
gen	lesscomptt_nonaligned_tp4=lesscomptt_nonaligned*yeardum17
gen	lesscomptt_nonaligned_tp3=lesscomptt_nonaligned*yeardum16
gen	lesscomptt_nonaligned_tp2=lesscomptt_nonaligned*yeardum15
gen	lesscomptt_nonaligned_tp1=lesscomptt_nonaligned*yeardum14	
gen	lesscomptt_nonaligned_t0=lesscomptt_nonaligned*yeardum13
gen	lesscomptt_nonaligned_tm1=lesscomptt_nonaligned*yeardum12
gen	lesscomptt_nonaligned_tm2=lesscomptt_nonaligned*yeardum11
gen	lesscomptt_nonaligned_tm3=lesscomptt_nonaligned*yeardum10
gen	lesscomptt_nonaligned_tm4=lesscomptt_nonaligned*yeardum9
gen	lesscomptt_nonaligned_tm5=lesscomptt_nonaligned*yeardum8
gen	lesscomptt_nonaligned_tm6=lesscomptt_nonaligned*yeardum7
gen	lesscomptt_nonaligned_tm7=lesscomptt_nonaligned*yeardum6
gen	lesscomptt_nonaligned_tm8=lesscomptt_nonaligned*yeardum5


gen zero=0
label variable zero "2006"	



label variable  lesscomptt_alignedgpps_tm8 "1998"
label variable  lesscomptt_alignedgpps_tm7 "1999"
label variable  lesscomptt_alignedgpps_tm6 "2000"
label variable  lesscomptt_alignedgpps_tm5 "2001"
label variable  lesscomptt_alignedgpps_tm4 "2002"
label variable  lesscomptt_alignedgpps_tm3 "2003"
label variable  lesscomptt_alignedgpps_tm2 "2004"
label variable  lesscomptt_alignedgpps_tm1 "2005"
label variable  lesscomptt_alignedgpps_t0  "2006"
label variable  lesscomptt_alignedgpps_tp1 "2007"
label variable  lesscomptt_alignedgpps_tp2 "2008"
label variable  lesscomptt_alignedgpps_tp3 "2009"
label variable  lesscomptt_alignedgpps_tp4 "2010"
label variable  lesscomptt_alignedgpps_tp5 "2011"


label variable  lesscomptt_nonaligned_tm8 "1998"
label variable  lesscomptt_nonaligned_tm7 "1999"
label variable  lesscomptt_nonaligned_tm6 "2000"
label variable  lesscomptt_nonaligned_tm5 "2001"
label variable  lesscomptt_nonaligned_tm4 "2002"
label variable  lesscomptt_nonaligned_tm3 "2003"
label variable  lesscomptt_nonaligned_tm2 "2004"
label variable  lesscomptt_nonaligned_tm1 "2005"
label variable  lesscomptt_nonaligned_t0  "2006"
label variable  lesscomptt_nonaligned_tp1 "2007"
label variable  lesscomptt_nonaligned_tp2 "2008"
label variable  lesscomptt_nonaligned_tp3 "2009"
label variable  lesscomptt_nonaligned_tp4 "2010"
label variable  lesscomptt_nonaligned_tp5 "2011"
	
*** 1998-2011 in Low competition 
eststo clear	
eststo: reg stdavg_private_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=1998 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpvtLC		
eststo: reg stdavg_publicadj_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=1998 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpubLC
*___			
drop 	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
		lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1  lesscomptt_alignedgpps  aligned_gpps ///
		lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 		
gen lesscomptt_alignedgpps_tp5= lesscomptt_nonaligned_tp5
gen lesscomptt_alignedgpps_tp4= lesscomptt_nonaligned_tp4		
gen lesscomptt_alignedgpps_tp3= lesscomptt_nonaligned_tp3		
gen lesscomptt_alignedgpps_tp2= lesscomptt_nonaligned_tp2 
gen lesscomptt_alignedgpps_tp1= lesscomptt_nonaligned_tp1 
gen lesscomptt_alignedgpps_tm2= lesscomptt_nonaligned_tm2
gen lesscomptt_alignedgpps_tm1= lesscomptt_nonaligned_tm1 
gen lesscomptt_alignedgpps_tm3= lesscomptt_nonaligned_tm3 
gen lesscomptt_alignedgpps_tm4= lesscomptt_nonaligned_tm4 
gen lesscomptt_alignedgpps_tm5= lesscomptt_nonaligned_tm5 
gen lesscomptt_alignedgpps_tm6= lesscomptt_nonaligned_tm6 
gen lesscomptt_alignedgpps_tm7= lesscomptt_nonaligned_tm7 
gen lesscomptt_alignedgpps_tm8= lesscomptt_nonaligned_tm8 
gen lesscomptt_alignedgpps= lesscomptt_nonaligned  
gen aligned_gpps= nonaligned
label variable  lesscomptt_alignedgpps_tm8 "1998"
label variable  lesscomptt_alignedgpps_tm7 "1999"
label variable  lesscomptt_alignedgpps_tm6 "2000"
label variable  lesscomptt_alignedgpps_tm5 "2001"
label variable  lesscomptt_alignedgpps_tm4 "2002"
label variable  lesscomptt_alignedgpps_tm3 "2003"
label variable  lesscomptt_alignedgpps_tm2 "2004"
label variable  lesscomptt_alignedgpps_tm1 "2005"
label variable  lesscomptt_alignedgpps_t0  "2006"
label variable  lesscomptt_alignedgpps_tp1 "2007"
label variable  lesscomptt_alignedgpps_tp2 "2008"
label variable  lesscomptt_alignedgpps_tp3 "2009"
label variable  lesscomptt_alignedgpps_tp4 "2010"
label variable  lesscomptt_alignedgpps_tp5 "2011"
eststo: reg stdavg_private_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=1998 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpvtLC_v2		
eststo: reg stdavg_publicadj_vill 	 ///
	lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 ///
	lesscomptt_alignedgpps_tp2 lesscomptt_alignedgpps_tp1 zero  lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 ///
	lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
	lesscomptt_alignedgpps	treatmorecompett treatlesscompett aligned_gpps ///
	delimcomm_member_assembly villagedum* yeardum* ///
	if year>=1998 & year<=2011, vce(cluster panchayatsamiti)
estimates store estpubLC_v2	
* coefplot (estpvtLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpvtHC, label(HC*Aligned) lpattern(dash_dot ) lcolor(gray) mcolor(white)) (estpvtLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///

coefplot (estpvtLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpvtLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
			lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1 zero lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm8   ) ///
		order(lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
			lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///	
		yline(0) omitted ci(90 myci) ///			  
		title(Private Benefits) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets
graph export "replication_output/FigureA2a_output.pdf", as(pdf) name("Graph") replace		
coefplot (estpubLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black)) (estpubLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///
		keep(lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
			lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1 zero lesscomptt_alignedgpps_tp2 ///
					lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5) ///
		order(lesscomptt_alignedgpps_tm8 lesscomptt_alignedgpps_tm7 lesscomptt_alignedgpps_tm6 lesscomptt_alignedgpps_tm5 lesscomptt_alignedgpps_tm4 lesscomptt_alignedgpps_tm3 ///	
			lesscomptt_alignedgpps_tm2 lesscomptt_alignedgpps_tm1 zero  lesscomptt_alignedgpps_tp1  lesscomptt_alignedgpps_tp2 ///
			lesscomptt_alignedgpps_tp3 lesscomptt_alignedgpps_tp4 lesscomptt_alignedgpps_tp5)  ///	
		yline(0) omitted ci(90 myci) ///			  
		title(Public Benefits) ytitle("Estimated Coefficients", height(7))    xtitle("Year", height(7))  ///
		graphregion(color(white))	legend(region(lcolor(white))  height(7))  recast(connected)  scale(0.8) ylabel(-3(2)3)  nooffsets		
graph export "replication_output/FigureA2b_output.pdf", as(pdf) name("Graph") replace				
*coefplot (estpubLC, label(LC*Aligned) lpattern(dash) lcolor(black) mcolor(black))  (estpubHC, label(HC*Aligned) lpattern(dash_dot ) lcolor(gray) mcolor(white)) (estpubLC_v2, label(LC*nonaligned) lcolor(gray) mcolor(gray)), vertical ///				 


*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.	
*** Figure A3
*~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.			 

clear 
use "VillageYear_Data.dta"

keep village prophh_noeduc prophh_landless prophh_scst prophh_noeduc_SECC prophh_landless_SECC prophh_scst_SECC 
	 
duplicates drop	

graph twoway (scatter prophh_scst prophh_scst_SECC, graphregion(color(white)) legend(off) ytitle(Sample Data, height(6)) xtitle(SECC Data, height(6))  title(Proportion of Households SC/ST, height(6))) ///
			(line  prophh_scst prophh_scst )
graph export "replication_output/FigureA3a_output.pdf", as(pdf) name("Graph") replace				
reg prophh_scst prophh_scst_SECC


graph twoway (scatter prophh_landless prophh_landless_SECC, graphregion(color(white)) legend(off) ytitle(Sample Data, height(6)) xtitle(SECC Data, height(6))  title(Proportion of Households Landless, height(6))) ///
			(line  prophh_landless prophh_landless )
graph export "replication_output/FigureA3b_output.pdf", as(pdf) name("Graph") replace				
reg prophh_landless prophh_landless_SECC


graph twoway (scatter prophh_noeduc prophh_noeduc_SECC, legend(off) ytitle(Sample Data, height(6)) xtitle(SECC Data, height(6))) ///
			(line prophh_noeduc prophh_noeduc, graphregion(color(white)) title(Proportion of HHs with No Literate Members Above Age 25,  height(6))  )	
graph export "replication_output/FigureA3c_output.pdf", as(pdf) name("Graph") replace				
reg prophh_noeduc prophh_noeduc_SECC
